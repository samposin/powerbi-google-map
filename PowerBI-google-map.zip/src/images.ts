export const ATM = require('./../assets/icons/ATM.png');
export const Office = require('./../assets/icons/Office.png');
// export const DataCenter = require('./../assets/icons/DataCenter.png');
export const thirdparty = require('./../assets/icons/thirdparty.png');